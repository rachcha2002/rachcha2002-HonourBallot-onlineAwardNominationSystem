#include "Item.h"
#include <iostream>
#include <cstring>
using namespace std;

Item::Item(int pItemNo, const char pName[])
{
	itemNo = pItemNo;
	strcpy_s(name, pName);
}

void Item::setPrice(double pPrice)
{
	price = pPrice;
}
double Item::calcTotal(int qty)
{
	return price * qty;
}
Item::~Item()
{
	cout << "Item No : " << itemNo << "Deleted" << endl;
}