#include <iostream>
#include "SalesPerson.h"
#include "Item.h"
using namespace std;
int main()
{
	/* SalesPerson s1(1000, "Wimal");
	Item item1(1001, "Shampoo");
	Item item2(1002, "Conditioner");

	item1.setPrice(550);
	item2.setPrice(650);

	s1.calcSales(item1, item2);
	s1.printSales(); */

	SalesPerson* s1;
	s1 = new SalesPerson(1000, "Wimal");

	Item* item1;
	item1 = new Item(1001, "Shampoo");

	Item* item2;
	item2 = new Item(1002, "Conditioner");

	item1->setPrice(550);
	item2->setPrice(650);

	s1->calcSales(*item1, *item2);
	s1->printSales();
}


